#Lesson 07, Episode 01, Game about fingers
